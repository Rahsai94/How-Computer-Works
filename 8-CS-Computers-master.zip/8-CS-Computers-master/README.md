8-CS-Computers
=============

A course teaching how Computer work, to include binary, logic gates and opcodes.
