function setup(){
    
    createCanvas(200, 250);
    // create a slider (min, max, default value)

}

function draw(){

}
