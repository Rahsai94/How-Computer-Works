function setup(){
    createCanvas(600, 500);
}

function animateObject(object,startx,endx,starty,endy){
    
}

function drawTest(object){
    fill(255,255,255)
    test(0,0,100,100)

function draw(){
    var test = rect
    drawTest(test)
}
