% How Computers Work
% by A. Turing
% Thursday, 1 January 1970

# What is a Computer?
- *Data* is a collection of facts, such as values or measurements.
- It can be numbers, words, measurements, observations or even just descriptions of things
- A **computer** is an electronic device that can store, retrieve, and process data.
![A Computer](http://www.buffalocomputerconsulting.com/images/computer.jpg)

## What is Hardware?

## What is Software?

# The different types of computers

## Embedded Computers

## Mobile Devices

## Microcomputers

## Servers

## Supercomputers

# The CPU

# Storage

## Non-volatile storage

## Volatile storage


