## This is a level 2 heading
### Obviously this is level 3

Unordered lists are cool

+ Here's the first bullet
+ And the second
+ Okay, let's have three

As are ordered lists

1. A numbered list would be good
1. It doesn't matter what numbers you used.
1. In Markdown the sequence will climb by one
9. Even if you add weird numbers
6. Like this

We can add horizontal rules like this 

- - -

And we can get code blocks by using tabs (or 4 spaces)

    var i = 10;
    console.log('Some statement')

Sometimes it's nice to get a *little* emphasis, though sometimes you want a **lot**

Sometimes we might want a link

[Daring Fireball Markdown Syntax](http://daringfireball.net/projects/markdown/syntax)

Sometimes we might want an image

![Daring Fireball Logo](http://daringfireball.net/graphics/logos/)
